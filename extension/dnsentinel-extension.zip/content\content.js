let l=window.location.origin;const d=new MutationObserver(o=>{for(const s of o)s.addedNodes.length&&s.addedNodes.forEach(t=>{if(t.tagName==="SCRIPT"&&t.src)try{const e=new URL(t.src);(e.hostname.length>30||/\d{5,}/.test(e.hostname))&&chrome.runtime.sendMessage({type:"SUSPICIOUS_NODE",payload:{url:t.src,origin:l}}).catch(()=>{})}catch{}})});d.observe(document.documentElement,{childList:!0,subtree:!0});chrome.runtime.sendMessage({type:"TAB_READY"}).catch(()=>{});chrome.runtime.onMessage.addListener((o,s,t)=>{o.type==="SHOW_TOAST"&&p(o.payload)});function p(o){if(window.self!==window.top)return;const s=document.getElementById("dnsentinel-toast");s&&s.remove();const t=o.tier!=="MONITOR",e=document.createElement("div");e.id="dnsentinel-toast",e.style.cssText=`
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 2147483647;
        font-family: 'Inter', system-ui, -apple-system, sans-serif;
        background: ${t?"rgba(20, 0, 0, 0.85)":"rgba(2, 6, 23, 0.85)"};
        backdrop-filter: blur(16px);
        -webkit-backdrop-filter: blur(16px);
        border: 1px solid ${t?"rgba(239, 68, 68, 0.4)":"rgba(34, 211, 238, 0.3)"};
        border-radius: 12px;
        padding: 16px;
        color: white;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5), inset 0 1px 0 0 rgba(255, 255, 255, 0.1);
        display: flex;
        flex-direction: column;
        gap: 12px;
        min-width: 340px;
        max-width: 400px;
        transform: translateX(120%);
        transition: transform 0.5s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.5s ease;
        opacity: 0;
    `;const i=document.createElement("div");i.style.cssText="display: flex; align-items: center; gap: 10px;";const a=document.createElement("div");a.innerHTML=t?"⚠️":"🛡️",a.style.cssText=`font-size: 20px; filter: drop-shadow(0 0 8px ${t?"rgba(239,68,68,0.5)":"rgba(34,211,238,0.5)"});`;const c=document.createElement("div");c.style.cssText=`font-weight: 700; font-size: 15px; flex-grow: 1; color: ${t?"#fca5a5":"#67e8f9"}; letter-spacing: 0.02em;`,c.textContent=t?"Suspicious Website Detected":"DNSentinel Active";const n=document.createElement("button");n.innerHTML="×",n.style.cssText="background: none; border: none; color: #94a3b8; font-size: 22px; cursor: pointer; padding: 0 4px; line-height: 1; transition: color 0.2s;",n.onmouseover=()=>n.style.color="white",n.onmouseout=()=>n.style.color="#94a3b8",n.onclick=()=>{e.style.transform="translateX(120%)",e.style.opacity="0"},i.appendChild(a),i.appendChild(c),i.appendChild(n),e.appendChild(i);const r=document.createElement("div");r.style.cssText="font-size: 13.5px; color: #cbd5e1; line-height: 1.5;",t?r.innerHTML=`DNSentinel flagged <strong>${o.domain}</strong> as a <span style="color:#f87171; font-weight:bold;">${o.tier}</span> risk (Score: ${(o.final_score||0).toFixed(2)}).`:r.innerHTML=`Secure connection to <strong style="color:white;">${o.domain}</strong>.`,e.appendChild(r),document.body.appendChild(e),requestAnimationFrame(()=>{e.style.transform="translateX(0)",e.style.opacity="1"}),t||setTimeout(()=>{e.style.transform="translateX(120%)",e.style.opacity="0",setTimeout(()=>e.remove(),500)},4e3)}
